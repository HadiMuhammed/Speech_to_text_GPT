from fastapi import FastAPI, WebSocket, Request
from fastapi.responses import HTMLResponse
from fastapi.templating import Jinja2Templates
import uvicorn
from core.ml_speech import detect_speech
from core.speech_to_text import speech_to_text
from core.gpt import gpt_response
import json
import io
import wave


router = FastAPI()
templates = Jinja2Templates(directory="templates")
AUDIO_FILE = "./temp/recorded_audio.wav"
# Greater than 50KB, we dont need small files, because API does not respond to small size files
# You can use this to control the speech length
AUDIO_BYTE_SIZE = 50000


def save_audio_to_wav(filename, audio_data):
    try:
        # Check if the audio data is empty or contains null bytes
        if audio_data == b"\x00":
            # print("Warning: Audio data contains null bytes or is empty, skipping save.")
            return

        with wave.open(filename, "wb") as wf:
            wf.setnchannels(1)
            wf.setsampwidth(2)  # 16-bit (2 bytes per sample)
            wf.setframerate(16000)
            wf.writeframes(audio_data)

        # print(f"Audio saved to {filename}")

    except Exception as e:
        print(f"Error saving audio: {e}")


@router.get("/")
async def get(request: Request):
    # Serves the index.html template
    return templates.TemplateResponse("index.html", {"request": request})


@router.websocket("/ws/{user_id}")
async def chat(websocket: WebSocket, user_id: str):
    await websocket.accept()
    try:
        while True:
            await handle_new_audio(websocket)
            if not websocket.application_satet.CONNECTED:
                break
    except Exception as e:
        print(f"Connection error: {e}")


async def handle_new_audio(websocket: WebSocket):
    temp_audio = io.BytesIO()
    talking = 0
    silence = 0  # loud environment, sometimes model classifies wrong label
    text = ""
    answer = ""
    while True:
        audio_data = await websocket.receive_bytes()
        prediction = detect_speech(audio_data)

        if prediction == "Speech":
            talking += 1
            silence = 0
            if len(audio_data) != 0:
                temp_audio.write(audio_data)

        elif prediction == "Silence":
            silence += 1
            if talking > 5 and silence > 5:
                audio_bytes = temp_audio.getvalue()
                if len(audio_bytes) > AUDIO_BYTE_SIZE:
                    save_audio_to_wav(AUDIO_FILE, audio_bytes)
                    # Connect with Whisper Api, get back text
                    await websocket.send_text(
                        json.dumps(
                            {
                                "prediction": prediction,
                                "text": "",
                                "loader": True,
                                "answer": answer,
                            }
                        )
                    )
                    try:
                        text = await speech_to_text()
                        if len(text) > 1:
                            answer = await gpt_response(text)
                    except:
                        text = "Error caused while converting Speech to Text"
                    temp_audio = io.BytesIO()
                talking = 0
                silence = 0

        elif prediction != "Speech" and prediction != "Silence":
            silence += 1

        if silence > 5:
            audio_bytes = temp_audio.getvalue()
            if len(audio_bytes) > AUDIO_BYTE_SIZE:
                save_audio_to_wav(AUDIO_FILE, audio_bytes)
                # Connect with Whisper Api, get back text
                await websocket.send_text(
                    json.dumps(
                        {
                            "prediction": prediction,
                            "text": "",
                            "loader": True,
                            "answer": answer,
                        }
                    )
                )
                try:
                    text = await speech_to_text()
                    if len(text) > 1:
                        answer = await gpt_response(text)
                except:
                    text = "Error caused while converting Speech to Text"
            temp_audio = io.BytesIO()
            talking = 0

        await websocket.send_text(
            json.dumps(
                {
                    "prediction": prediction,
                    "text": text,
                    "loader": False,
                    "answer": answer,
                }
            )
        )


if __name__ == "__main__":
    uvicorn.run(router, host="127.0.0.1", port=8080)
