import requests
import os
from core.config import API_KEY

AUDIO_FILE = "./temp/recorded_audio.wav"
# URL for openai
url = "https://api.openai.com/v1/audio/transcriptions"
headers = {
    "Authorization": f"Bearer {API_KEY}",  # Authorization
}

data = {
    "model": "whisper-1",
    "response_format": "text",
    "language": "en",
}

# Use this like a cache to avoid calling api everytime
# This is a quick fix
# This can be used to check if the file has changed
cache = 0
response = {}


async def speech_to_text():
    global cache, response
    try:
        # Open our saved audio into a var
        with open(AUDIO_FILE, "rb") as audio_file:
            files = {"file": audio_file}
            last_file_size = os.path.getsize(AUDIO_FILE)
            if last_file_size != cache:
                cache = last_file_size
                response = requests.post(url, headers=headers, files=files, data=data)

        # Check if the response is successful
        if response:
            if response.status_code == 200:
                return response.text  # Return the transcribed text
            else:
                print("Error:", response.status_code, response.text)
                return "Error processing audio file"

    except Exception as e:
        print(f"An error occurred: {e}")
        return "An error occurred during the request"
