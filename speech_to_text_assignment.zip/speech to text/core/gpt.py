import openai
from core.config import API_KEY

# Set up your API key (ensure this is kept secure and private)
openai.api_key = API_KEY
response = []


async def gpt_response(prompt):
    try:
        # Use the chat completion endpoint with the GPT-4 model
        response = openai.ChatCompletion.create(
            model="gpt-4",
            messages=[
                {"role": "system", "content": "You are a helpful assistant."},
                {"role": "user", "content": prompt},
            ],
        )
        # Extract the response text from the API response
        if response:
            answer = response["choices"][0]["message"]["content"]
            return answer

    except Exception as e:
        print(f"An error occurred: {e}")
        return "Error in generating response"
