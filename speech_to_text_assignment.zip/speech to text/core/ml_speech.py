# import wave
import numpy as np
import tensorflow as tf
import zipfile

# Audio stream configuration
TARGET_LENGTH = 15600
audio_buffer = np.zeros(TARGET_LENGTH, dtype=np.float32)
model_path = './ML_Model/1.tflite'
interpreter = tf.lite.Interpreter(model_path=model_path)
interpreter.allocate_tensors()

input_details = interpreter.get_input_details()
output_details = interpreter.get_output_details()

waveform_input_index = input_details[0]['index']
scores_output_index = output_details[0]['index']


with zipfile.ZipFile(model_path) as z:
    with z.open('yamnet_label_list.txt') as f:
        labels = [line.decode('utf-8').strip() for line in f]

# Ensure the input tensor is correctly sized
interpreter.resize_tensor_input(waveform_input_index, [TARGET_LENGTH], strict=False)
interpreter.allocate_tensors()

def detect_speech(audio_chunk):
    global audio_buffer, waveform_input_index, scores_output_index, interpreter
    try:
        # Check if audio_chunk is empty
        if not audio_chunk:
            print("Received an empty audio chunk, skipping...")
            return "No audio detected"

        # Check that the chunk size is a multiple of 2 (to match int16 format)
        if len(audio_chunk) % 2 != 0:
            print(f"Received audio chunk of invalid size: {len(audio_chunk)} bytes")
            return "Invalid audio chunk size"

        # Convert audio bytes to float32 format
        audio_data = np.frombuffer(audio_chunk, dtype=np.int16).astype(np.float32) / 32768.0

        # Update the audio buffer
        audio_buffer = np.roll(audio_buffer, -len(audio_data))
        audio_buffer[-len(audio_data):] = audio_data

        # Set the tensor data
        interpreter.set_tensor(waveform_input_index, audio_buffer)

        # Run the model
        interpreter.invoke()
        scores = interpreter.get_tensor(scores_output_index)

        # Get the top classification result
        top_class_index = scores.argmax()
        prediction = labels[top_class_index]
        return prediction
    except KeyboardInterrupt:
        # Handle the KeyboardInterrupt to stop recording
        print("\nRecording stopped by user.")