install
pip install openai==0.28
pip install uvicorn

run python3 main.py
